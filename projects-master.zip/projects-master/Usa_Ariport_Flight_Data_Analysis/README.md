## Dataset
#### Due to large file size i am not able to upload the data set to here. but you can ge the dataset from [here](https://drive.google.com/file/d/17f3ot73GCpnwjb3hBBrzqe57ZNMAFWLk/view?usp=sharing).

## Requirements
- python
- pandas
- numpy 
- matplotlib
- seaborn
- folium
- plotly
