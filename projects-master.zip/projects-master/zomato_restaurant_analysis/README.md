## Dataset

- Find Dataset link [here](https://www.kaggle.com/himanshupoddar/zomato-bangalore-restaurants)

## Notebook

- for clear and Neat explanation look into **zomato_final.ipynb**.
- This notebook is in **Python 3.6** with all the necessary packages required for analysis.

### Thank you for visiting.
